"""Główny plik uruchamiający aplikację.

Uruchomienie:
    python run.py
"""

from datetime import datetime, timedelta
import random

from app import create_app
from app.models import Booking, Equipment, Room, User, db

app = create_app()


def seed_database():
    """Wypełnia pustą bazę przykładowymi danymi do testowania."""

    if User.query.first():
        print("Baza już zawiera dane. Pomijam seeding.")
        return

    print("Tworzenie przykładowych danych...")

    equipment_list = [
        Equipment(name="Projektor", icon="projector"),
        Equipment(name="Tablica", icon="chalkboard"),
        Equipment(name="Wideokonferencja", icon="video"),
        Equipment(name="Klimatyzacja", icon="snowflake"),
        Equipment(name="Nagłośnienie", icon="volume-up"),
        Equipment(name="Monitor", icon="display"),
    ]
    db.session.add_all(equipment_list)

    rooms = [
        Room(
            name="Sala A1",
            capacity=10,
            floor=1,
            description="Mała sala do spotkań zespołowych",
            hourly_rate=50,
        ),
        Room(
            name="Sala B2",
            capacity=20,
            floor=2,
            description="Średnia sala z projektorem",
            hourly_rate=80,
        ),
        Room(
            name="Sala Konferencyjna",
            capacity=50,
            floor=3,
            description="Duża sala na prezentacje i szkolenia",
            hourly_rate=150,
        ),
        Room(
            name="Pokój Kreatywny",
            capacity=8,
            floor=1,
            description="Sala do burzy mózgów z tablicami",
            hourly_rate=60,
        ),
    ]

    rooms[0].equipment = [equipment_list[1], equipment_list[3]]
    rooms[1].equipment = [equipment_list[0], equipment_list[2], equipment_list[3]]
    rooms[2].equipment = equipment_list
    rooms[3].equipment = [equipment_list[1], equipment_list[5]]
    db.session.add_all(rooms)

    users = [
        User(name="Jan Kowalski", email="jan@firma.pl", department="IT"),
        User(name="Anna Nowak", email="anna@firma.pl", department="HR"),
        User(name="Piotr Wiśniewski", email="piotr@firma.pl", department="Marketing"),
        User(name="Maria Dąbrowska", email="maria@firma.pl", department="IT", is_admin=True),
        User(name="Ewa Zielińska", email="ewa@firma.pl", department="Sprzedaż"),
    ]
    db.session.add_all(users)
    db.session.commit()

    titles = [
        "Spotkanie zespołu",
        "Code review",
        "Prezentacja projektu",
        "Rozmowa rekrutacyjna",
        "Szkolenie",
        "Planning sprint",
        "Retrospektywa",
        "Demo dla klienta",
    ]

    now = datetime.now().replace(minute=0, second=0, microsecond=0)

    # Celowe spotkanie za około godzinę do testu przypomnień.
    first_room = rooms[0]
    first_user = users[0]
    db.session.add(
        Booking(
            room=first_room,
            user=first_user,
            title="Spotkanie testowe za 1h",
            start_time=now + timedelta(hours=1),
            end_time=now + timedelta(hours=2),
            attendees_count=4,
        )
    )
    db.session.commit()

    created = 1
    attempts = 0

    while created < 35 and attempts < 300:
        attempts += 1
        room = random.choice(rooms)
        user = random.choice(users)
        days_offset = random.randint(0, 29)
        hour = random.randint(8, 17)
        duration = random.choice([1, 2, 3])

        start = (now + timedelta(days=days_offset)).replace(hour=hour)
        end = start + timedelta(hours=duration)

        if room.is_available(start, end):
            booking = Booking(
                room=room,
                user=user,
                title=random.choice(titles),
                start_time=start,
                end_time=end,
                attendees_count=random.randint(2, room.capacity),
            )
            db.session.add(booking)
            created += 1

    db.session.commit()
    print(f"✅ Baza danych wypełniona przykładowymi danymi. Rezerwacje: {created}")


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        seed_database()

    app.run(debug=True, port=5000)
