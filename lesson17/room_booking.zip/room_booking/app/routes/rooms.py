"""Endpointy API dla sal i wyposażenia."""

from flask import Blueprint, jsonify, request
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload

from app.models import Equipment, Room, db

rooms_bp = Blueprint("rooms", __name__, url_prefix="/api/rooms")


@rooms_bp.route("/", methods=["GET"])
def get_rooms():
    query = Room.query.options(joinedload(Room.equipment))

    if active := request.args.get("active"):
        query = query.filter(Room.is_active == (active.lower() == "true"))

    if min_capacity := request.args.get("min_capacity", type=int):
        query = query.filter(Room.capacity >= min_capacity)

    rooms = query.order_by(Room.floor, Room.name).all()
    return jsonify({"rooms": [room.to_dict() for room in rooms]})


@rooms_bp.route("/<int:room_id>", methods=["GET"])
def get_room(room_id):
    room = Room.query.options(joinedload(Room.equipment)).filter_by(id=room_id).first_or_404()
    return jsonify({"room": room.to_dict()})


@rooms_bp.route("/", methods=["POST"])
def create_room():
    data = request.get_json() or {}

    for field in ["name", "capacity"]:
        if field not in data:
            return jsonify({"error": f"Brak wymaganego pola: {field}"}), 400

    room = Room(
        name=data["name"],
        capacity=int(data["capacity"]),
        floor=int(data.get("floor", 0)),
        description=data.get("description"),
        is_active=bool(data.get("is_active", True)),
        hourly_rate=data.get("hourly_rate", 0),
    )

    equipment_ids = data.get("equipment_ids", [])
    if equipment_ids:
        room.equipment = Equipment.query.filter(Equipment.id.in_(equipment_ids)).all()

    try:
        db.session.add(room)
        db.session.commit()
        return jsonify({"message": "Sala utworzona", "room": room.to_dict()}), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify({"error": "Sala o takiej nazwie już istnieje."}), 400
    except Exception as exc:
        db.session.rollback()
        return jsonify({"error": str(exc)}), 500


@rooms_bp.route("/<int:room_id>", methods=["PUT"])
def update_room(room_id):
    room = db.session.get(Room, room_id)
    if room is None:
        return jsonify({"error": "Sala nie istnieje."}), 404

    data = request.get_json() or {}

    for field in ["name", "capacity", "floor", "description", "is_active", "hourly_rate"]:
        if field in data:
            setattr(room, field, data[field])

    if "equipment_ids" in data:
        room.equipment = Equipment.query.filter(Equipment.id.in_(data["equipment_ids"])).all()

    try:
        db.session.commit()
        return jsonify({"message": "Sala zaktualizowana", "room": room.to_dict()})
    except IntegrityError:
        db.session.rollback()
        return jsonify({"error": "Sala o takiej nazwie już istnieje."}), 400
    except Exception as exc:
        db.session.rollback()
        return jsonify({"error": str(exc)}), 500


@rooms_bp.route("/<int:room_id>", methods=["DELETE"])
def delete_room(room_id):
    room = db.session.get(Room, room_id)
    if room is None:
        return jsonify({"error": "Sala nie istnieje."}), 404

    try:
        db.session.delete(room)
        db.session.commit()
        return jsonify({"message": "Sala usunięta"})
    except Exception as exc:
        db.session.rollback()
        return jsonify({"error": str(exc)}), 500


@rooms_bp.route("/equipment", methods=["GET"])
def get_equipment():
    equipment = Equipment.query.order_by(Equipment.name).all()
    return jsonify({"equipment": [item.to_dict() for item in equipment]})


@rooms_bp.route("/equipment", methods=["POST"])
def create_equipment():
    data = request.get_json() or {}

    if "name" not in data:
        return jsonify({"error": "Brak wymaganego pola: name"}), 400

    item = Equipment(name=data["name"], icon=data.get("icon"))

    try:
        db.session.add(item)
        db.session.commit()
        return jsonify({"message": "Wyposażenie utworzone", "equipment": item.to_dict()}), 201
    except IntegrityError:
        db.session.rollback()
        return jsonify({"error": "Takie wyposażenie już istnieje."}), 400
