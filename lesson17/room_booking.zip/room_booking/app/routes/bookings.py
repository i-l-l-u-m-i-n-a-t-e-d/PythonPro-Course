"""Endpointy API dla rezerwacji."""

from datetime import datetime

from flask import Blueprint, jsonify, request
from sqlalchemy.orm import joinedload

from app.models import (
    Booking,
    Room,
    User,
    create_booking_from_payload,
    create_recurring_bookings,
    db,
    find_available_rooms,
    get_conflicts,
    parse_iso_datetime,
)

bookings_bp = Blueprint("bookings", __name__, url_prefix="/api/bookings")


@bookings_bp.route("/", methods=["GET"])
def get_bookings():
    query = Booking.query.options(joinedload(Booking.room), joinedload(Booking.user))

    if room_id := request.args.get("room_id", type=int):
        query = query.filter(Booking.room_id == room_id)

    if user_id := request.args.get("user_id", type=int):
        query = query.filter(Booking.user_id == user_id)

    if date_str := request.args.get("date"):
        try:
            date = datetime.strptime(date_str, "%Y-%m-%d").date()
        except ValueError:
            return jsonify({"error": "Data musi mieć format YYYY-MM-DD."}), 400
        query = query.filter(db.func.date(Booking.start_time) == date)

    if status := request.args.get("status"):
        query = query.filter(Booking.status == status)

    if series_id := request.args.get("series_id"):
        query = query.filter(Booking.series_id == series_id)

    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)

    pagination = query.order_by(Booking.start_time.desc()).paginate(
        page=page,
        per_page=per_page,
        error_out=False,
    )

    return jsonify(
        {
            "bookings": [
                booking.to_dict(include_room=True, include_user=True)
                for booking in pagination.items
            ],
            "total": pagination.total,
            "pages": pagination.pages,
            "current_page": page,
        }
    )


@bookings_bp.route("/<int:booking_id>", methods=["GET"])
def get_booking(booking_id):
    booking = Booking.query.options(joinedload(Booking.room), joinedload(Booking.user)).filter_by(id=booking_id).first_or_404()
    return jsonify({"booking": booking.to_dict(include_room=True, include_user=True)})


@bookings_bp.route("/", methods=["POST"])
def create_booking():
    data = request.get_json() or {}

    try:
        booking = create_booking_from_payload(data)
        return jsonify(
            {
                "message": "Rezerwacja utworzona",
                "booking": booking.to_dict(include_room=True, include_user=True),
            }
        ), 201
    except LookupError as exc:
        db.session.rollback()
        return jsonify({"error": str(exc)}), 404
    except RuntimeError as exc:
        db.session.rollback()
        detail = exc.args[0] if exc.args else {"message": "Konflikt rezerwacji."}
        return jsonify({"error": detail}), 409
    except ValueError as exc:
        db.session.rollback()
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        db.session.rollback()
        return jsonify({"error": f"Błąd tworzenia rezerwacji: {exc}"}), 500


@bookings_bp.route("/<int:booking_id>", methods=["PUT"])
def update_booking(booking_id):
    booking = db.session.get(Booking, booking_id)
    if booking is None:
        return jsonify({"error": "Rezerwacja nie istnieje."}), 404

    data = request.get_json() or {}

    start_time = booking.start_time
    end_time = booking.end_time

    if "start_time" in data:
        start_time = parse_iso_datetime(data["start_time"], "start_time")

    if "end_time" in data:
        end_time = parse_iso_datetime(data["end_time"], "end_time")

    if start_time >= end_time:
        return jsonify({"error": "Czas rozpoczęcia musi być przed czasem zakończenia."}), 400

    room_id = int(data.get("room_id", booking.room_id))
    room = db.session.get(Room, room_id)
    if room is None:
        return jsonify({"error": "Sala nie istnieje."}), 404

    if not room.is_available(start_time, end_time, exclude_booking_id=booking.id):
        return jsonify(
            {
                "error": "Sala jest już zarezerwowana w tym czasie.",
                "conflicts": get_conflicts(room.id, start_time, end_time, booking.id),
            }
        ), 409

    user_id = int(data.get("user_id", booking.user_id))
    user = db.session.get(User, user_id)
    if user is None:
        return jsonify({"error": "Użytkownik nie istnieje."}), 404

    attendees = int(data.get("attendees_count", booking.attendees_count))
    if attendees > room.capacity:
        return jsonify({"error": f"Zbyt wielu uczestników. Pojemność sali: {room.capacity}."}), 400

    booking.room_id = room.id
    booking.user_id = user.id
    booking.title = data.get("title", booking.title)
    booking.description = data.get("description", booking.description)
    booking.start_time = start_time
    booking.end_time = end_time
    booking.attendees_count = attendees
    booking.status = data.get("status", booking.status)

    try:
        db.session.commit()
        return jsonify({"message": "Rezerwacja zaktualizowana", "booking": booking.to_dict(True, True)})
    except Exception as exc:
        db.session.rollback()
        return jsonify({"error": str(exc)}), 500


@bookings_bp.route("/<int:booking_id>", methods=["DELETE"])
def cancel_booking(booking_id):
    scope = request.args.get("scope", "single")
    booking = db.session.get(Booking, booking_id)

    if booking is None:
        return jsonify({"error": "Rezerwacja nie istnieje."}), 404

    if booking.start_time < datetime.now() and scope == "single":
        return jsonify({"error": "Nie można anulować przeszłej rezerwacji."}), 400

    try:
        if scope == "series" and booking.series_id:
            updated = Booking.query.filter_by(series_id=booking.series_id).update(
                {"status": "cancelled"}
            )
            db.session.commit()
            return jsonify({"message": "Seria anulowana", "updated": updated})

        if booking.status == "cancelled":
            return jsonify({"error": "Rezerwacja już anulowana."}), 400

        booking.status = "cancelled"
        db.session.commit()
        return jsonify({"message": "Rezerwacja anulowana"})
    except Exception as exc:
        db.session.rollback()
        return jsonify({"error": str(exc)}), 500


@bookings_bp.route("/available-rooms", methods=["GET"])
def find_available():
    try:
        start_time = parse_iso_datetime(request.args["start_time"], "start_time")
        end_time = parse_iso_datetime(request.args["end_time"], "end_time")
    except (KeyError, ValueError) as exc:
        return jsonify({"error": str(exc)}), 400

    capacity = request.args.get("capacity", 1, type=int)

    equipment = None
    if eq_param := request.args.get("equipment"):
        equipment = [item.strip() for item in eq_param.split(",") if item.strip()]

    rooms = find_available_rooms(start_time, end_time, capacity, equipment)

    return jsonify(
        {
            "available_rooms": [room.to_dict() for room in rooms],
            "search_criteria": {
                "start_time": start_time.isoformat(),
                "end_time": end_time.isoformat(),
                "min_capacity": capacity,
                "required_equipment": equipment,
            },
        }
    )


@bookings_bp.route("/recurring", methods=["POST"])
def create_recurring():
    data = request.get_json() or {}

    try:
        bookings = create_recurring_bookings(data)
        return jsonify(
            {
                "message": "Seria rezerwacji utworzona",
                "series_id": bookings[0].series_id,
                "count": len(bookings),
                "bookings": [booking.to_dict(include_room=True) for booking in bookings],
            }
        ), 201
    except LookupError as exc:
        return jsonify({"error": str(exc)}), 404
    except RuntimeError as exc:
        detail = exc.args[0] if exc.args else {"message": "Konflikt serii."}
        return jsonify({"error": detail}), 409
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    except Exception as exc:
        db.session.rollback()
        return jsonify({"error": str(exc)}), 500
