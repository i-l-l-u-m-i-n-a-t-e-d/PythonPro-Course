"""Raport PDF dla rezerwacji miesięcznych."""

from datetime import datetime
from io import BytesIO

from flask import Blueprint, Response, jsonify, request
from reportlab.graphics.charts.barcharts import VerticalBarChart
from reportlab.graphics.shapes import Drawing
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
from sqlalchemy import func

from app.models import Booking, Room, User, db

reports_bp = Blueprint("reports", __name__, url_prefix="/api/reports")


def month_range(month_value):
    try:
        start = datetime.strptime(month_value, "%Y-%m")
    except ValueError as exc:
        raise ValueError("Parametr month musi mieć format YYYY-MM, np. 2026-06.") from exc

    if start.month == 12:
        end = datetime(start.year + 1, 1, 1)
    else:
        end = datetime(start.year, start.month + 1, 1)

    return start, end


def table_style():
    return TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("ALIGN", (1, 1), (-1, -1), "RIGHT"),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
        ]
    )


def build_utilization_chart(room_rows):
    drawing = Drawing(420, 180)
    chart = VerticalBarChart()
    chart.x = 40
    chart.y = 35
    chart.height = 120
    chart.width = 340

    values = [float(row.total_hours or 0) for row in room_rows[:10]] or [0]
    chart.data = [values]
    chart.categoryAxis.categoryNames = [row.name[:12] for row in room_rows[:10]] or ["Brak"]
    chart.valueAxis.valueMin = 0
    chart.valueAxis.valueMax = max(values) + 1
    chart.valueAxis.valueStep = max(1, int(chart.valueAxis.valueMax / 5))
    chart.bars[0].fillColor = colors.HexColor("#667eea")
    drawing.add(chart)
    return drawing


@reports_bp.route("/monthly", methods=["GET"])
def monthly_report():
    month_value = request.args.get("month")
    if not month_value:
        return jsonify({"error": "Wymagany parametr month=YYYY-MM"}), 400

    try:
        start, end = month_range(month_value)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    bookings_filter = [
        Booking.start_time >= start,
        Booking.start_time < end,
        Booking.status != "cancelled",
    ]

    total_bookings = Booking.query.filter(*bookings_filter).count()
    total_hours = (
        db.session.query(func.sum(func.extract("epoch", Booking.end_time - Booking.start_time) / 3600))
        .filter(*bookings_filter)
        .scalar()
        or 0
    )
    revenue = (
        db.session.query(
            func.sum(
                (func.extract("epoch", Booking.end_time - Booking.start_time) / 3600)
                * Room.hourly_rate
            )
        )
        .select_from(Booking)
        .join(Room, Booking.room_id == Room.id)
        .filter(*bookings_filter)
        .scalar()
        or 0
    )

    top_rooms = (
        db.session.query(
            Room.name,
            func.count(Booking.id).label("booking_count"),
            func.sum(func.extract("epoch", Booking.end_time - Booking.start_time) / 3600).label("total_hours"),
        )
        .select_from(Room)
        .join(Booking, Booking.room_id == Room.id)
        .filter(*bookings_filter)
        .group_by(Room.id, Room.name)
        .order_by(func.count(Booking.id).desc())
        .limit(10)
        .all()
    )

    top_users = (
        db.session.query(User.name, User.department, func.count(Booking.id).label("booking_count"))
        .select_from(User)
        .join(Booking, Booking.user_id == User.id)
        .filter(*bookings_filter)
        .group_by(User.id, User.name, User.department)
        .order_by(func.count(Booking.id).desc())
        .limit(10)
        .all()
    )
    top_rooms = (
        db.session.query(
            Room.name,
            func.count(Booking.id).label("booking_count"),
            func.sum(func.extract("epoch", Booking.end_time - Booking.start_time) / 3600).label("total_hours"),
        )
        .join(Booking)
        .filter(*bookings_filter)
        .group_by(Room.id)
        .order_by(func.count(Booking.id).desc())
        .limit(10)
        .all()
    )

    top_users = (
        db.session.query(User.name, User.department, func.count(Booking.id).label("booking_count"))
        .join(Booking)
        .filter(*bookings_filter)
        .group_by(User.id)
        .order_by(func.count(Booking.id).desc())
        .limit(10)
        .all()
    )

    buffer = BytesIO()
    document = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=2 * cm, leftMargin=2 * cm)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph(f"Raport miesięczny rezerwacji: {month_value}", styles["Title"]))
    story.append(Spacer(1, 12))

    summary_data = [
        ["Metryka", "Wartość"],
        ["Liczba rezerwacji", str(total_bookings)],
        ["Łączny czas", f"{float(total_hours):.1f} h"],
        ["Przychód", f"{float(revenue):.2f} PLN"],
    ]
    summary_table = Table(summary_data, hAlign="LEFT")
    summary_table.setStyle(table_style())
    story.append(summary_table)
    story.append(Spacer(1, 18))

    story.append(Paragraph("Top 10 sal", styles["Heading2"]))
    room_data = [["Sala", "Rezerwacje", "Godziny"]]
    for row in top_rooms:
        room_data.append([row.name, row.booking_count, f"{float(row.total_hours or 0):.1f}"])
    if len(room_data) == 1:
        room_data.append(["Brak danych", "0", "0"])
    room_table = Table(room_data, hAlign="LEFT")
    room_table.setStyle(table_style())
    story.append(room_table)
    story.append(Spacer(1, 18))

    story.append(Paragraph("Top 10 użytkowników", styles["Heading2"]))
    user_data = [["Użytkownik", "Departament", "Rezerwacje"]]
    for row in top_users:
        user_data.append([row.name, row.department or "-", row.booking_count])
    if len(user_data) == 1:
        user_data.append(["Brak danych", "-", "0"])
    user_table = Table(user_data, hAlign="LEFT")
    user_table.setStyle(table_style())
    story.append(user_table)
    story.append(Spacer(1, 18))

    story.append(Paragraph("Wykres wykorzystania sal", styles["Heading2"]))
    story.append(build_utilization_chart(top_rooms))

    document.build(story)
    buffer.seek(0)

    filename = f"monthly-report-{month_value}.pdf"
    return Response(
        buffer.getvalue(),
        mimetype="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
