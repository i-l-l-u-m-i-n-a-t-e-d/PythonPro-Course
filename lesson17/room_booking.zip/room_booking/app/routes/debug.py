"""Endpoint diagnostyczny do pokazania problemu N+1."""

import time

from flask import Blueprint, jsonify
from sqlalchemy import event
from sqlalchemy.orm import joinedload

from app.models import Booking, db


debug_bp = Blueprint("debug", __name__, url_prefix="/debug")


@debug_bp.route("/n-plus-1")
def n_plus_1():
    query_counter = {"count": 0}

    def count_queries(conn, cursor, statement, parameters, context, executemany):
        query_counter["count"] += 1

    event.listen(db.engine, "before_cursor_execute", count_queries)

    try:
        query_counter["count"] = 0
        start = time.perf_counter()

        bad_rows = []
        bookings = Booking.query.all()
        for booking in bookings:
            bad_rows.append(
                {
                    "title": booking.title,
                    "room": booking.room.name,
                    "user": booking.user.name,
                }
            )

        bad_time = time.perf_counter() - start
        bad_queries = query_counter["count"]

        query_counter["count"] = 0
        start = time.perf_counter()

        good_rows = []
        optimized_bookings = Booking.query.options(
            joinedload(Booking.room),
            joinedload(Booking.user),
        ).all()
        for booking in optimized_bookings:
            good_rows.append(
                {
                    "title": booking.title,
                    "room": booking.room.name,
                    "user": booking.user.name,
                }
            )

        good_time = time.perf_counter() - start
        good_queries = query_counter["count"]

        return jsonify(
            {
                "without_optimization": {
                    "sql_queries": bad_queries,
                    "time_ms": round(bad_time * 1000, 2),
                    "rows": bad_rows[:10],
                },
                "with_joinedload": {
                    "sql_queries": good_queries,
                    "time_ms": round(good_time * 1000, 2),
                    "rows": good_rows[:10],
                },
                "difference": {
                    "queries_saved": bad_queries - good_queries,
                    "note": "joinedload pobiera salę i użytkownika razem z rezerwacją.",
                },
            }
        )
    finally:
        event.remove(db.engine, "before_cursor_execute", count_queries)
