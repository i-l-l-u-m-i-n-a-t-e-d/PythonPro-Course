"""Blueprinty aplikacji."""
