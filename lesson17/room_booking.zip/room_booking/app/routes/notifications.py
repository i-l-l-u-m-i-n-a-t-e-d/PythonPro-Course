"""Endpointy powiadomień."""

from flask import Blueprint, jsonify, request

from app.models import Notification, db, generate_booking_reminders

notifications_bp = Blueprint("notifications", __name__, url_prefix="/api/notifications")


@notifications_bp.route("/", methods=["GET"])
def unread_notifications():
    user_id = request.args.get("user_id", type=int)

    query = Notification.query.filter_by(is_read=False)

    if user_id:
        query = query.filter_by(user_id=user_id)

    notifications = query.order_by(Notification.created_at.desc()).all()
    return jsonify({"notifications": [item.to_dict() for item in notifications]})


@notifications_bp.route("/<int:notification_id>/read", methods=["POST"])
def mark_as_read(notification_id):
    notification = db.session.get(Notification, notification_id)
    if notification is None:
        return jsonify({"error": "Powiadomienie nie istnieje."}), 404

    notification.is_read = True
    db.session.commit()

    return jsonify({"message": "Powiadomienie oznaczone jako przeczytane"})


@notifications_bp.route("/generate-reminders", methods=["POST"])
def generate_reminders():
    created = generate_booking_reminders()
    return jsonify({"message": "Przypomnienia wygenerowane", "created": created})
