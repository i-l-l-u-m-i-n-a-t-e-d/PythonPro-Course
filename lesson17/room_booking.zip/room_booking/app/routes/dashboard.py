"""Dashboard HTML i endpointy statystyk."""

from datetime import datetime, timedelta

from flask import Blueprint, jsonify, render_template
from sqlalchemy import desc, func
from sqlalchemy.orm import joinedload

from app.models import (
    Booking,
    Room,
    User,
    db,
    get_booking_statistics,
    get_extended_dashboard_statistics,
)


dashboard_bp = Blueprint("dashboard", __name__)


@dashboard_bp.route("/dashboard")
def dashboard():
    stats = {
        "total_rooms": Room.query.filter_by(is_active=True).count(),
        "total_users": User.query.count(),
        "total_bookings": Booking.query.filter_by(status="confirmed").count(),
        "bookings_today": Booking.query.filter(
            func.date(Booking.start_time) == datetime.today().date(),
            Booking.status == "confirmed",
        ).count(),
    }

    now = datetime.now()
    upcoming = (
        Booking.query.options(joinedload(Booking.room), joinedload(Booking.user))
        .filter(
            Booking.start_time >= now,
            Booking.start_time <= now + timedelta(hours=24),
            Booking.status == "confirmed",
        )
        .order_by(Booking.start_time)
        .limit(10)
        .all()
    )

    top_users = (
        db.session.query(User.name, func.count(Booking.id).label("booking_count"))
        .join(Booking)
        .filter(Booking.status != "cancelled")
        .group_by(User.id)
        .order_by(desc("booking_count"))
        .limit(5)
        .all()
    )

    month_ago = now - timedelta(days=30)
    room_utilization = []

    active_rooms = Room.query.filter_by(is_active=True).all()
    for room in active_rooms:
        total_hours = (
            db.session.query(
                func.sum(func.extract("epoch", Booking.end_time - Booking.start_time) / 3600)
            )
            .filter(
                Booking.room_id == room.id,
                Booking.start_time >= month_ago,
                Booking.status != "cancelled",
            )
            .scalar()
            or 0
        )

        max_hours = 176
        utilization = (float(total_hours) / max_hours) * 100
        room_utilization.append(
            {
                "room": room.name,
                "hours": round(float(total_hours), 1),
                "utilization": round(utilization, 1),
            }
        )

    room_utilization.sort(key=lambda item: item["utilization"], reverse=True)

    return render_template(
        "dashboard.html",
        stats=stats,
        upcoming=upcoming,
        top_users=top_users,
        room_utilization=room_utilization,
    )


@dashboard_bp.route("/api/dashboard/stats")
def api_stats():
    return jsonify(get_booking_statistics())


@dashboard_bp.route("/api/dashboard/extended")
def api_extended_stats():
    return jsonify(get_extended_dashboard_statistics())
