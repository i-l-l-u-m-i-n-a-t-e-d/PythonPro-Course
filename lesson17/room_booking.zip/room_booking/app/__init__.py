"""Fabryka aplikacji Flask dla systemu rezerwacji sal."""

from datetime import datetime, timedelta
import os

from flask import Flask, jsonify, redirect

from config import config
from app.models import db


def create_app(config_name=None):
    app = Flask(__name__)

    selected_config = config_name or os.getenv("FLASK_ENV", "development")
    app.config.from_object(config.get(selected_config, config["default"]))
    app.config["LAST_REMINDER_CHECK"] = None

    db.init_app(app)

    from app.routes.rooms import rooms_bp
    from app.routes.bookings import bookings_bp
    from app.routes.dashboard import dashboard_bp
    from app.routes.debug import debug_bp
    from app.routes.notifications import notifications_bp
    from app.routes.reports import reports_bp
    from app.models import generate_booking_reminders

    app.register_blueprint(rooms_bp)
    app.register_blueprint(bookings_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(debug_bp)
    app.register_blueprint(notifications_bp)
    app.register_blueprint(reports_bp)

    @app.before_request
    def auto_generate_reminders():
        """Prosty mechanizm przypomnień bez dodatkowego schedulera.

        Przy każdym ruchu w aplikacji sprawdza maksymalnie raz na minutę,
        czy istnieją rezerwacje zaczynające się za około 1 godzinę.
        """

        now = datetime.now()
        last_check = app.config.get("LAST_REMINDER_CHECK")

        if last_check and now - last_check < timedelta(minutes=1):
            return None

        app.config["LAST_REMINDER_CHECK"] = now

        try:
            generate_booking_reminders(now)
        except Exception:
            db.session.rollback()

        return None

    @app.route("/")
    def index():
        return redirect("/dashboard")

    @app.route("/test-db")
    def test_db():
        try:
            db.session.execute(db.text("SELECT 1"))
            return jsonify({"ok": True, "message": "Połączenie z PostgreSQL OK"})
        except Exception as exc:
            return jsonify({"ok": False, "error": str(exc)}), 500

    return app
