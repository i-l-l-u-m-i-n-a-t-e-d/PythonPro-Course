"""Modele bazy danych dla pełnego systemu rezerwacji sal.

Zakres obejmuje:
- sale, wyposażenie, użytkowników i rezerwacje,
- relacje 1:N oraz M:N,
- walidację konfliktów rezerwacji,
- powiadomienia,
- rezerwacje cykliczne,
- statystyki dashboardu.
"""

from datetime import datetime, timedelta
from uuid import uuid4

import sqlalchemy as sa
from dateutil.rrule import DAILY, MONTHLY, WEEKLY, rrule
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import event, func
from sqlalchemy.orm import joinedload


db = SQLAlchemy()


room_equipment = db.Table(
    "room_equipment",
    db.Column("room_id", db.Integer, db.ForeignKey("rooms.id"), primary_key=True),
    db.Column(
        "equipment_id", db.Integer, db.ForeignKey("equipment.id"), primary_key=True
    ),
)


class User(db.Model):
    """Użytkownik systemu."""

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    department = db.Column(db.String(50))
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    bookings = db.relationship("Booking", backref="user", lazy="dynamic")
    notifications = db.relationship(
        "Notification", backref="user", lazy="dynamic", cascade="all, delete-orphan"
    )

    def __repr__(self):
        return f"<User {self.email}>"

    def to_dict(self):
        return {
            "id": self.id,
            "email": self.email,
            "name": self.name,
            "department": self.department,
            "is_admin": self.is_admin,
        }


class Equipment(db.Model):
    """Wyposażenie sali, np. projektor, tablica, wideokonferencja."""

    __tablename__ = "equipment"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)
    icon = db.Column(db.String(50))

    def __repr__(self):
        return f"<Equipment {self.name}>"

    def to_dict(self):
        return {"id": self.id, "name": self.name, "icon": self.icon}


class Room(db.Model):
    """Sala konferencyjna."""

    __tablename__ = "rooms"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    capacity = db.Column(db.Integer, nullable=False)
    floor = db.Column(db.Integer, default=0)
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    hourly_rate = db.Column(db.Numeric(10, 2), default=0)

    bookings = db.relationship(
        "Booking",
        backref="room",
        lazy="dynamic",
        cascade="all, delete-orphan",
    )

    equipment = db.relationship(
        "Equipment",
        secondary=room_equipment,
        lazy="subquery",
        backref=db.backref("rooms", lazy=True),
    )

    def __repr__(self):
        return f"<Room {self.name} (cap: {self.capacity})>"

    def to_dict(self, include_equipment=True):
        data = {
            "id": self.id,
            "name": self.name,
            "capacity": self.capacity,
            "floor": self.floor,
            "description": self.description,
            "is_active": self.is_active,
            "hourly_rate": float(self.hourly_rate or 0),
        }

        if include_equipment:
            data["equipment"] = [item.to_dict() for item in self.equipment]

        return data

    def is_available(self, start_time, end_time, exclude_booking_id=None):
        """Sprawdza, czy sala jest wolna w podanym przedziale czasu."""

        query = Booking.query.filter(
            Booking.room_id == self.id,
            Booking.status != "cancelled",
            Booking.start_time < end_time,
            Booking.end_time > start_time,
        )

        if exclude_booking_id:
            query = query.filter(Booking.id != exclude_booking_id)

        return query.count() == 0


class Booking(db.Model):
    """Rezerwacja sali."""

    __tablename__ = "bookings"

    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey("rooms.id"), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)

    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)

    start_time = db.Column(db.DateTime, nullable=False)
    end_time = db.Column(db.DateTime, nullable=False)

    status = db.Column(db.String(20), default="confirmed", nullable=False)
    attendees_count = db.Column(db.Integer, default=1)

    recurrence_rule = db.Column(db.String(30))
    series_id = db.Column(db.String(36), index=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow
    )

    __table_args__ = (
        db.Index("idx_booking_room_time", "room_id", "start_time", "end_time"),
    )

    def __repr__(self):
        return f"<Booking {self.title} ({self.start_time})>"

    @property
    def duration_hours(self):
        delta = self.end_time - self.start_time
        return delta.total_seconds() / 3600

    @property
    def total_cost(self):
        if self.room and self.room.hourly_rate:
            return float(self.room.hourly_rate) * self.duration_hours
        return 0

    def to_dict(self, include_room=False, include_user=False):
        data = {
            "id": self.id,
            "room_id": self.room_id,
            "user_id": self.user_id,
            "title": self.title,
            "description": self.description,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat(),
            "status": self.status,
            "attendees_count": self.attendees_count,
            "duration_hours": round(self.duration_hours, 2),
            "total_cost": round(self.total_cost, 2),
            "recurrence_rule": self.recurrence_rule,
            "series_id": self.series_id,
        }

        if include_room:
            data["room"] = self.room.to_dict(include_equipment=False)

        if include_user:
            data["user"] = self.user.to_dict()

        return data


class Notification(db.Model):
    """Powiadomienie systemowe dla użytkownika."""

    __tablename__ = "notifications"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    message = db.Column(db.String(255), nullable=False)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "message": self.message,
            "is_read": self.is_read,
            "created_at": self.created_at.isoformat(),
        }


@event.listens_for(Booking, "after_insert")
def create_admin_notification(mapper, connection, target):
    """Tworzy powiadomienie dla każdego admina po dodaniu rezerwacji."""

    users_table = User.__table__
    notifications_table = Notification.__table__

    admins = connection.execute(
        sa.select(users_table.c.id).where(users_table.c.is_admin.is_(True))
    ).fetchall()

    for admin in admins:
        connection.execute(
            notifications_table.insert().values(
                user_id=admin.id,
                message=(
                    f"Nowa rezerwacja: '{target.title}' "
                    f"dla sali ID {target.room_id}."
                ),
                is_read=False,
                created_at=datetime.utcnow(),
            )
        )


def parse_iso_datetime(value, field_name="datetime"):
    """Zamienia tekst ISO na datetime i zwraca czytelny błąd."""

    try:
        return datetime.fromisoformat(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Niepoprawny format pola {field_name}. Użyj ISO.") from exc


def get_conflicts(room_id, start_time, end_time, exclude_booking_id=None):
    """Zwraca rezerwacje kolidujące z podanym przedziałem."""

    query = Booking.query.options(joinedload(Booking.room), joinedload(Booking.user)).filter(
        Booking.room_id == room_id,
        Booking.status != "cancelled",
        Booking.start_time < end_time,
        Booking.end_time > start_time,
    )

    if exclude_booking_id:
        query = query.filter(Booking.id != exclude_booking_id)

    return [
        {
            "id": item.id,
            "title": item.title,
            "start": item.start_time.isoformat(),
            "end": item.end_time.isoformat(),
            "room": item.room.name,
            "user": item.user.name,
        }
        for item in query.order_by(Booking.start_time).all()
    ]


def find_available_rooms(start_time, end_time, min_capacity=1, required_equipment=None):
    """Znajduje dostępne sale spełniające warunki pojemności i wyposażenia."""

    query = Room.query.options(joinedload(Room.equipment)).filter(
        Room.is_active.is_(True),
        Room.capacity >= min_capacity,
    )

    if required_equipment:
        for equipment_name in required_equipment:
            query = query.filter(Room.equipment.any(Equipment.name == equipment_name))

    candidate_rooms = query.order_by(Room.capacity).all()
    return [room for room in candidate_rooms if room.is_available(start_time, end_time)]


def recurrence_frequency(rule_name):
    """Mapuje prostą nazwę reguły na ustawienia dateutil.rrule."""

    normalized = (rule_name or "").upper()

    if normalized == "DAILY":
        return DAILY, 1

    if normalized == "WEEKLY":
        return WEEKLY, 1

    if normalized == "BIWEEKLY":
        return WEEKLY, 2

    if normalized == "MONTHLY":
        return MONTHLY, 1

    raise ValueError("Dozwolone recurrence_rule: DAILY, WEEKLY, BIWEEKLY, MONTHLY")


def build_recurrence_dates(start_time, recurrence_rule, occurrences=None, until=None):
    """Buduje listę dat startu dla rezerwacji cyklicznych."""

    freq, interval = recurrence_frequency(recurrence_rule)

    if occurrences is None and until is None:
        occurrences = 12

    rule_kwargs = {"freq": freq, "dtstart": start_time, "interval": interval}

    if occurrences:
        rule_kwargs["count"] = int(occurrences)

    if until:
        rule_kwargs["until"] = until

    return list(rrule(**rule_kwargs))


def create_booking_from_payload(data, commit=True):
    """Tworzy pojedynczą rezerwację z walidacją."""

    required = ["room_id", "user_id", "title", "start_time", "end_time"]
    for field in required:
        if field not in data:
            raise ValueError(f"Brak wymaganego pola: {field}")

    start_time = parse_iso_datetime(data["start_time"], "start_time")
    end_time = parse_iso_datetime(data["end_time"], "end_time")

    if start_time >= end_time:
        raise ValueError("Czas rozpoczęcia musi być przed czasem zakończenia.")

    if start_time < datetime.now():
        raise ValueError("Nie można rezerwować w przeszłości.")

    room = db.session.get(Room, data["room_id"])
    if room is None:
        raise LookupError("Sala nie istnieje.")

    if not room.is_active:
        raise ValueError("Sala jest nieaktywna.")

    user = db.session.get(User, data["user_id"])
    if user is None:
        raise LookupError("Użytkownik nie istnieje.")

    attendees = int(data.get("attendees_count", 1))
    if attendees > room.capacity:
        raise ValueError(f"Zbyt wielu uczestników. Pojemność sali: {room.capacity}.")

    if not room.is_available(start_time, end_time, data.get("exclude_booking_id")):
        conflicts = get_conflicts(room.id, start_time, end_time, data.get("exclude_booking_id"))
        raise RuntimeError({"message": "Sala jest już zarezerwowana.", "conflicts": conflicts})

    booking = Booking(
        room_id=room.id,
        user_id=user.id,
        title=data["title"],
        description=data.get("description"),
        start_time=start_time,
        end_time=end_time,
        attendees_count=attendees,
        recurrence_rule=data.get("recurrence_rule"),
        series_id=data.get("series_id"),
    )

    db.session.add(booking)

    if commit:
        db.session.commit()

    return booking


def create_recurring_bookings(data):
    """Tworzy serię rezerwacji po pełnej walidacji konfliktów."""

    recurrence_rule = data.get("recurrence_rule", "WEEKLY")
    start_time = parse_iso_datetime(data["start_time"], "start_time")
    end_time = parse_iso_datetime(data["end_time"], "end_time")
    duration = end_time - start_time

    until = None
    if data.get("until"):
        until = parse_iso_datetime(data["until"], "until")

    occurrences = data.get("occurrences")
    starts = build_recurrence_dates(start_time, recurrence_rule, occurrences, until)

    if not starts:
        raise ValueError("Nie wygenerowano żadnych wystąpień serii.")

    room = db.session.get(Room, data["room_id"])
    if room is None:
        raise LookupError("Sala nie istnieje.")

    conflicts = []
    for item_start in starts:
        item_end = item_start + duration
        conflicts.extend(get_conflicts(room.id, item_start, item_end))

    if conflicts:
        raise RuntimeError({"message": "Seria ma konflikty.", "conflicts": conflicts})

    series_id = str(uuid4())
    bookings = []

    try:
        for item_start in starts:
            item_end = item_start + duration
            payload = dict(data)
            payload["start_time"] = item_start.isoformat()
            payload["end_time"] = item_end.isoformat()
            payload["recurrence_rule"] = recurrence_rule
            payload["series_id"] = series_id
            booking = create_booking_from_payload(payload, commit=False)
            bookings.append(booking)

        db.session.commit()
        return bookings

    except Exception:
        db.session.rollback()
        raise


def generate_booking_reminders(now=None):
    """Tworzy przypomnienia dla rezerwacji zaczynających się za około godzinę."""

    now = now or datetime.now()
    window_start = now + timedelta(minutes=55)
    window_end = now + timedelta(minutes=65)

    bookings = Booking.query.filter(
        Booking.status == "confirmed",
        Booking.start_time >= window_start,
        Booking.start_time <= window_end,
    ).all()

    created = 0

    for booking in bookings:
        message = f"Przypomnienie: rezerwacja '{booking.title}' zaczyna się za około 1h."
        exists = Notification.query.filter_by(
            user_id=booking.user_id,
            message=message,
            is_read=False,
        ).first()

        if exists:
            continue

        db.session.add(Notification(user_id=booking.user_id, message=message))
        created += 1

    db.session.commit()
    return created


def get_booking_statistics(start_date=None, end_date=None):
    """Podstawowe statystyki rezerwacji."""

    base_query = Booking.query.filter(Booking.status != "cancelled")

    if start_date:
        base_query = base_query.filter(Booking.start_time >= start_date)

    if end_date:
        base_query = base_query.filter(Booking.end_time <= end_date)

    total_bookings = base_query.count()

    room_stats = (
        db.session.query(
            Room.name,
            func.count(Booking.id).label("booking_count"),
            func.sum(func.extract("epoch", Booking.end_time - Booking.start_time) / 3600).label(
                "total_hours"
            ),
        )
        .join(Booking)
        .filter(Booking.status != "cancelled")
        .group_by(Room.name)
        .order_by(func.count(Booking.id).desc())
        .all()
    )

    weekday_stats = (
        db.session.query(
            func.extract("dow", Booking.start_time).label("weekday"),
            func.count(Booking.id).label("count"),
        )
        .filter(Booking.status != "cancelled")
        .group_by("weekday")
        .order_by("weekday")
        .all()
    )

    weekdays = ["Nd", "Pn", "Wt", "Śr", "Cz", "Pt", "Sb"]

    return {
        "total_bookings": total_bookings,
        "room_stats": [
            {
                "room": item.name,
                "bookings": item.booking_count,
                "hours": round(float(item.total_hours or 0), 1),
            }
            for item in room_stats
        ],
        "weekday_stats": [
            {"day": weekdays[int(item.weekday)], "count": item.count}
            for item in weekday_stats
        ],
    }


def get_extended_dashboard_statistics(days=30):
    """Statystyki wymagane w zadaniu 3."""

    now = datetime.now()
    start = now - timedelta(days=days)

    department_rows = (
        db.session.query(User.department, func.count(Booking.id).label("count"))
        .join(Booking)
        .filter(Booking.status != "cancelled")
        .group_by(User.department)
        .order_by(func.count(Booking.id).desc())
        .all()
    )

    heatmap_rows = (
        db.session.query(
            func.extract("dow", Booking.start_time).label("weekday"),
            func.extract("hour", Booking.start_time).label("hour"),
            func.count(Booking.id).label("count"),
        )
        .filter(Booking.status != "cancelled")
        .group_by("weekday", "hour")
        .order_by("weekday", "hour")
        .all()
    )

    trend_rows = (
        db.session.query(
            func.date(Booking.start_time).label("day"),
            func.count(Booking.id).label("count"),
        )
        .filter(Booking.status != "cancelled", Booking.start_time >= start)
        .group_by("day")
        .order_by("day")
        .all()
    )

    weekdays = ["Nd", "Pn", "Wt", "Śr", "Cz", "Pt", "Sb"]
    heatmap = []

    for day_index, day_name in enumerate(weekdays):
        for hour in range(8, 19):
            matching = [
                item for item in heatmap_rows
                if int(item.weekday) == day_index and int(item.hour) == hour
            ]
            heatmap.append(
                {
                    "day": day_name,
                    "hour": hour,
                    "count": matching[0].count if matching else 0,
                }
            )

    return {
        "department_distribution": [
            {"department": item.department or "Brak", "count": item.count}
            for item in department_rows
        ],
        "heatmap": heatmap,
        "daily_trend": [
            {"date": item.day.isoformat(), "count": item.count}
            for item in trend_rows
        ],
    }
