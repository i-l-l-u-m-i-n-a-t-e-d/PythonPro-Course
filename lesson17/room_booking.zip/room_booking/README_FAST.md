# Room Booking — pełne wymagania z lekcji 18

Ten projekt realizuje pełny praktyczny zakres PDF-a:

- Flask + PostgreSQL,
- relacje 1:N oraz M:N,
- CRUD sal,
- rezerwacje z walidacją konfliktów,
- dashboard ze statystykami,
- API REST,
- endpoint N+1 z porównaniem joinedload,
- rozszerzone statystyki dashboardu,
- system powiadomień,
- rezerwacje cykliczne,
- raport miesięczny PDF.

## Start

```bash
python -m venv .venv
```

Windows:

```powershell
.\.venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
source .venv/bin/activate
```

```bash
pip install -r requirements.txt
cp .env.example .env
# Windows: copy .env.example .env
docker compose up -d
python run.py
```

## Kontrola

- http://127.0.0.1:5000/test-db
- http://127.0.0.1:5000/dashboard
- http://127.0.0.1:5000/api/rooms/
- http://127.0.0.1:5000/api/bookings/
- http://127.0.0.1:5000/debug/n-plus-1
- http://127.0.0.1:5000/api/dashboard/extended
- http://127.0.0.1:5000/api/reports/monthly?month=2026-06

## Test rezerwacji zwykłej

```bash
curl -X POST http://127.0.0.1:5000/api/bookings/ \
  -H "Content-Type: application/json" \
  -d '{"room_id":1,"user_id":1,"title":"Nowa rezerwacja","start_time":"2026-12-01T10:00:00","end_time":"2026-12-01T11:00:00","attendees_count":4}'
```

## Test rezerwacji cyklicznej

```bash
curl -X POST http://127.0.0.1:5000/api/bookings/recurring \
  -H "Content-Type: application/json" \
  -d '{"room_id":2,"user_id":2,"title":"Cotygodniowy status","start_time":"2026-12-02T10:00:00","end_time":"2026-12-02T11:00:00","attendees_count":5,"recurrence_rule":"WEEKLY","occurrences":6}'
```

## Test powiadomień

```bash
curl -X POST http://127.0.0.1:5000/api/notifications/generate-reminders
curl http://127.0.0.1:5000/api/notifications/
```
