CREATE DATABASE room_booking;
